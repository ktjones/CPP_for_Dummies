// Savings - define a class that includes the ability
//           to make a deposit
class Savings
{
  public:
    // declare but don't define member function
    float deposit(float amount);
    unsigned int accountNumber;
    float  balance;
};
